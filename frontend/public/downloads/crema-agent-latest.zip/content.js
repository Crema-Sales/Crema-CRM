"use strict";
(() => {
  // src/background/sites.ts
  var SITES = [
    {
      id: "gmail",
      label: "Gmail",
      matches: ["https://mail.google.com/*"],
      hostSuffixes: ["mail.google.com"]
    },
    {
      id: "outlook",
      label: "Outlook",
      matches: [
        "https://outlook.office.com/*",
        "https://outlook.office365.com/*",
        "https://outlook.live.com/*"
      ],
      hostSuffixes: ["outlook.office.com", "outlook.office365.com", "outlook.live.com"]
    },
    {
      id: "linkedin",
      label: "LinkedIn",
      matches: ["https://www.linkedin.com/*"],
      hostSuffixes: ["linkedin.com"]
    },
    {
      id: "teams",
      label: "Microsoft Teams",
      matches: ["https://teams.microsoft.com/*"],
      hostSuffixes: ["teams.microsoft.com"]
    }
  ];
  var ALLOWLIST_KEY = "siteAllowlist";
  async function getAllowlist() {
    const out = await chrome.storage.local.get(ALLOWLIST_KEY);
    const stored = out[ALLOWLIST_KEY] ?? {};
    const full = {};
    for (const s of SITES) full[s.id] = stored[s.id] !== false;
    return full;
  }
  async function isSiteAllowed(id) {
    return (await getAllowlist())[id];
  }
  function siteForUrl(url) {
    let host;
    try {
      host = new URL(url).hostname;
    } catch {
      return void 0;
    }
    return SITES.find((s) => s.hostSuffixes.some((h) => host === h || host.endsWith(`.${h}`)));
  }

  // src/content/emit.ts
  var SUBJECT_CAP = 200;
  var PREVIEW_CAP = 280;
  var SEEN_CAP = 500;
  function makeEmitter() {
    const seen = /* @__PURE__ */ new Set();
    return (event) => {
      if (seen.has(event.dedupeKey)) return;
      seen.add(event.dedupeKey);
      if (seen.size > SEEN_CAP) {
        const oldest = seen.values().next().value;
        if (oldest !== void 0) seen.delete(oldest);
      }
      const clean = {
        ...event,
        subject: event.subject?.slice(0, SUBJECT_CAP),
        preview: event.preview?.slice(0, PREVIEW_CAP)
      };
      try {
        chrome.runtime.sendMessage({ type: "activity_event", event: clean }, () => {
          void chrome.runtime.lastError;
        });
        console.log("[crema-capture] event:", clean.kind, clean.contact ?? "");
      } catch (err) {
        console.warn("[crema-capture] emit failed:", err);
      }
    };
  }

  // src/content/util.ts
  function txt(el) {
    return (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function pick(root, ...selectors) {
    for (const s of selectors) {
      try {
        const el = root.querySelector(s);
        if (el) return el;
      } catch {
      }
    }
    return null;
  }
  function closestMatch(el, selectors) {
    for (const s of selectors) {
      try {
        const found = el.closest(s);
        if (found) return found;
      } catch {
      }
    }
    return null;
  }
  function onDocumentClick(handler) {
    const listener = (ev) => {
      if (ev.target instanceof Element) {
        try {
          handler(ev.target);
        } catch (err) {
          console.warn("[crema-capture] click handler threw:", err);
        }
      }
    };
    document.addEventListener("click", listener, true);
    return () => document.removeEventListener("click", listener, true);
  }
  function debounce(fn, ms) {
    let timer = null;
    return () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(fn, ms);
    };
  }
  function hash(input) {
    let h = 5381;
    for (let i = 0; i < input.length; i++) h = (h << 5) + h + input.charCodeAt(i) | 0;
    return (h >>> 0).toString(36);
  }
  function extractEmail(s) {
    const m = s.match(/[\w.+-]+@[\w-]+\.[\w.-]+/);
    return m ? m[0].toLowerCase() : void 0;
  }

  // src/content/adapters/gmail.ts
  var SEND_BTN = [
    'div[role=button][data-tooltip^="Send"]',
    'div[role=button][aria-label^="Send"]'
  ];
  var COMPOSE_DIALOG = ["div[role=dialog]", "div.nH.Hd", "div.aoP"];
  var LIST_ROOT = ["div[role=main]"];
  var startGmail = (emit) => {
    const offClick = onDocumentClick((target) => {
      const btn = closestMatch(target, SEND_BTN);
      if (!btn) return;
      const dialog = closestMatch(btn, COMPOSE_DIALOG) ?? document;
      const chips = Array.from(dialog.querySelectorAll("[email]")).map((c) => ({
        email: (c.getAttribute("email") ?? "").toLowerCase(),
        name: c.getAttribute("name") ?? txt(c)
      })).filter((r) => r.email);
      const to = chips[0];
      const subjectInput = pick(dialog, "input[name=subjectbox]");
      const subject = subjectInput?.value || txt(pick(dialog, "h2.hP"));
      const preview = txt(pick(dialog, "div[aria-label='Message Body']", "div[role=textbox]"));
      emit({
        kind: "email_sent",
        site: "gmail",
        occurredAt: Date.now(),
        contact: to ? { email: to.email, name: to.name } : void 0,
        subject,
        preview,
        url: location.href,
        // bucket to 2s so a double-click on Send coalesces into one event
        dedupeKey: `gmail:sent:${hash((to?.email ?? "") + subject)}:${Math.floor(Date.now() / 2e3)}`
      });
    });
    const root = pick(document, ...LIST_ROOT);
    const baseline = /* @__PURE__ */ new Set();
    function rowKey(row) {
      const id = row.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id") ?? row.querySelector("[data-thread-id]")?.getAttribute("data-thread-id") ?? row.getAttribute("id");
      if (id) return id;
      return hash(txt(row).slice(0, 120));
    }
    function scanRows(emitNew) {
      const rows = Array.from(document.querySelectorAll("tr.zA"));
      for (const row of rows) {
        const key = rowKey(row);
        if (baseline.has(key)) continue;
        baseline.add(key);
        if (!emitNew) continue;
        const sender = row.querySelector("span[email]");
        const email = (sender?.getAttribute("email") ?? "").toLowerCase();
        const name = sender?.getAttribute("name") ?? txt(sender);
        const subject = txt(pick(row, ".bog", "[data-thread-id] span"));
        const snippet = txt(pick(row, ".y2"));
        emit({
          kind: "email_received",
          site: "gmail",
          occurredAt: Date.now(),
          contact: email || name ? { email: email || void 0, name } : void 0,
          subject,
          preview: snippet,
          url: location.href,
          dedupeKey: `gmail:recv:${key}`
        });
      }
    }
    scanRows(false);
    const observer = new MutationObserver(debounce(() => scanRows(true), 400));
    if (root) observer.observe(root, { childList: true, subtree: true });
    return () => {
      offClick();
      observer.disconnect();
    };
  };

  // src/content/adapters/outlook.ts
  var SEND_BTN2 = [
    'button[aria-label="Send"]',
    'button[aria-label^="Send" i]',
    'div[aria-label="Send"][role=button]'
  ];
  var COMPOSE = ['div[aria-label="Message body"]', "div[role=dialog]", "div[aria-label*='compose' i]"];
  var LIST_ROOT2 = ["div[role=listbox]", "div[role=list]", "div[aria-label*='message list' i]"];
  var startOutlook = (emit) => {
    const offClick = onDocumentClick((target) => {
      const btn = closestMatch(target, SEND_BTN2);
      if (!btn) return;
      const dialog = closestMatch(btn, COMPOSE) ?? document;
      const pill = pick(
        dialog,
        'div[role=option][title*="@"]',
        'span[title*="@"]',
        'div[aria-label*="@"]'
      );
      const pillText = pill ? `${pill.getAttribute("title") ?? ""} ${txt(pill)}` : "";
      const email = extractEmail(pillText);
      const name = pill?.getAttribute("title")?.replace(/<[^>]*>/g, "").trim() || txt(pill) || void 0;
      const subjectEl = pick(dialog, 'input[aria-label*="subject" i]');
      const subject = subjectEl?.value ?? "";
      const preview = txt(pick(dialog, 'div[aria-label="Message body"]', "div[role=textbox]"));
      emit({
        kind: "email_sent",
        site: "outlook",
        occurredAt: Date.now(),
        contact: email || name ? { email, name } : void 0,
        subject,
        preview,
        url: location.href,
        dedupeKey: `outlook:sent:${hash((email ?? "") + subject)}:${Math.floor(Date.now() / 2e3)}`
      });
    });
    const root = pick(document, ...LIST_ROOT2);
    const baseline = /* @__PURE__ */ new Set();
    function scanRows(emitNew) {
      const rows = Array.from(document.querySelectorAll("div[role=option]"));
      for (const row of rows) {
        const label = row.getAttribute("aria-label") ?? txt(row);
        const key = row.getAttribute("data-convid") ?? hash(label.slice(0, 140));
        if (baseline.has(key)) continue;
        baseline.add(key);
        if (!emitNew) continue;
        const senderEl = pick(row, "span[title]", "[class*='SenderName']");
        const name = senderEl?.getAttribute("title") || txt(senderEl) || void 0;
        const email = extractEmail(label);
        emit({
          kind: "email_received",
          site: "outlook",
          occurredAt: Date.now(),
          contact: email || name ? { email, name } : void 0,
          preview: label,
          url: location.href,
          dedupeKey: `outlook:recv:${key}`
        });
      }
    }
    scanRows(false);
    const observer = new MutationObserver(debounce(() => scanRows(true), 400));
    if (root) observer.observe(root, { childList: true, subtree: true });
    return () => {
      offClick();
      observer.disconnect();
    };
  };

  // src/content/adapters/linkedin.ts
  var COMMENT_POST_BTN = [
    "button.comments-comment-box__submit-button",
    "button.comments-comment-texteditor__submit",
    "button[class*='comments-comment-box'][class*='submit']"
  ];
  var MSG_SEND_BTN = ["button.msg-form__send-button", "button[class*='msg-form__send']"];
  var POST_CONTAINER = ["div.feed-shared-update-v2", "article", "div[data-urn]"];
  var POST_AUTHOR = [
    ".update-components-actor__title",
    ".update-components-actor__name",
    "span.feed-shared-actor__name"
  ];
  var THREAD_TITLE = [
    ".msg-entity-lockup__entity-title",
    "h2#thread-detail-jump-target",
    ".msg-thread__link-to-profile"
  ];
  var startLinkedIn = (emit) => {
    const offClick = onDocumentClick((target) => {
      if (closestMatch(target, COMMENT_POST_BTN)) {
        const post = closestMatch(target, POST_CONTAINER);
        const author = post ? txt(pick(post, ...POST_AUTHOR)) : "";
        const urn = post?.getAttribute("data-urn") ?? "";
        const postUrl = urn ? `https://www.linkedin.com/feed/update/${urn}` : location.href;
        emit({
          kind: "linkedin_comment",
          site: "linkedin",
          occurredAt: Date.now(),
          contact: author ? { name: author } : void 0,
          preview: author ? `Commented on ${author}'s post` : "Commented on a LinkedIn post",
          url: postUrl,
          dedupeKey: `linkedin:comment:${hash(urn + author)}:${Math.floor(Date.now() / 2e3)}`
        });
        return;
      }
      if (closestMatch(target, MSG_SEND_BTN)) {
        const titleEl = pick(document, ...THREAD_TITLE);
        const name = txt(titleEl);
        const profileLink = pick(document, "a.msg-thread__link-to-profile");
        const draft = txt(pick(document, "div.msg-form__contenteditable", "div[role=textbox]"));
        emit({
          kind: "linkedin_message",
          site: "linkedin",
          occurredAt: Date.now(),
          contact: name ? { name, profileUrl: profileLink?.href || void 0 } : void 0,
          preview: draft,
          url: location.href,
          dedupeKey: `linkedin:msg:${hash(name + draft.slice(0, 40))}:${Math.floor(Date.now() / 2e3)}`
        });
      }
    });
    return () => offClick();
  };

  // src/content/adapters/teams.ts
  var SEND_BTN3 = [
    'button[data-tid="newMessageCommands-send"]',
    'button[name="send"]',
    'button[aria-label^="Send" i]'
  ];
  var CHAT_TITLE = [
    '[data-tid="chat-header-title"]',
    '[data-tid="threadHeaderTitle"]',
    '[data-tid="title"]',
    "h1, h2"
  ];
  var COMPOSE_BOX = [
    'div[data-tid="ckeditor"]',
    "div[role=textbox]",
    "div[contenteditable=true]"
  ];
  var startTeams = (emit) => {
    const offClick = onDocumentClick((target) => {
      if (!closestMatch(target, SEND_BTN3)) return;
      const title = txt(pick(document, ...CHAT_TITLE));
      const draft = txt(pick(document, ...COMPOSE_BOX));
      emit({
        kind: "teams_message",
        site: "teams",
        occurredAt: Date.now(),
        contact: title ? { name: title } : void 0,
        preview: draft,
        url: location.href,
        dedupeKey: `teams:msg:${hash(title + draft.slice(0, 40))}:${Math.floor(Date.now() / 2e3)}`
      });
    });
    return () => offClick();
  };

  // src/content/index.ts
  var ADAPTERS = {
    gmail: startGmail,
    outlook: startOutlook,
    linkedin: startLinkedIn,
    teams: startTeams
  };
  function main(site2) {
    const emit = makeEmitter();
    let teardown = null;
    async function evaluate() {
      const { agentEnabled } = await chrome.storage.local.get("agentEnabled");
      const masterOn = agentEnabled !== false;
      const siteOn = await isSiteAllowed(site2.id);
      const shouldRun = masterOn && siteOn;
      if (shouldRun && !teardown) {
        console.log(`[crema-capture] adapter active: ${site2.id}`);
        teardown = ADAPTERS[site2.id](emit);
      } else if (!shouldRun && teardown) {
        console.log(`[crema-capture] adapter stopped: ${site2.id}`);
        teardown();
        teardown = null;
      }
    }
    void evaluate();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.agentEnabled || changes.siteAllowlist) void evaluate();
    });
  }
  var site = siteForUrl(location.href);
  if (site) {
    main(site);
  } else {
    console.log("[crema-capture] no adapter for", location.host);
  }
})();
//# sourceMappingURL=content.js.map
