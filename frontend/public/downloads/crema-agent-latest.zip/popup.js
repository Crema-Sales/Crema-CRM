// src/popup/popup.ts
function send(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (resp) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve(resp);
    });
  });
}
function $(id) {
  const el = document.getElementById(id);
  if (!el) throw new Error(`#${id} missing from popup.html`);
  return el;
}
var CONN_LABEL = {
  open: "Connected",
  connecting: "Connecting",
  closed: "Reconnecting",
  idle: "Not linked"
};
var state = null;
function render() {
  if (!state) return;
  const conn = $("conn");
  conn.textContent = CONN_LABEL[state.connection] ?? state.connection;
  conn.dataset.status = state.connection;
  $("master-toggle").setAttribute("aria-checked", String(state.masterEnabled));
  const sub = $("master-sub");
  if (!state.masterEnabled) sub.textContent = "Paused \u2014 nothing captured or driven";
  else if (state.activity === "driving") sub.textContent = "Driving your browser";
  else if (state.activity === "recording") sub.textContent = "Recording activity";
  else sub.textContent = "On \u2014 watching for activity";
  const list = $("site-list");
  list.textContent = "";
  for (const s of state.sites) {
    const li = document.createElement("li");
    const label = document.createElement("span");
    label.textContent = s.label;
    const cb = document.createElement("button");
    cb.className = "site-switch";
    cb.setAttribute("role", "switch");
    cb.setAttribute("aria-checked", String(s.allowed));
    cb.setAttribute("aria-label", s.label);
    cb.disabled = !state.masterEnabled;
    cb.addEventListener("click", () => {
      void (async () => {
        await send({ type: "popup_set_site", siteId: s.id, enabled: !s.allowed });
        await refresh();
      })();
    });
    li.append(label, cb);
    list.append(li);
  }
  $("rep").textContent = state.repId ? `Rep: ${state.repId}` : "Not linked to a rep account";
}
async function refresh() {
  try {
    state = await send({ type: "popup_get_state" });
    render();
  } catch (err) {
    $("conn").textContent = "ASLEEP";
    console.warn("[popup] refresh failed:", err);
  }
}
$("master-toggle").addEventListener("click", () => {
  void (async () => {
    if (!state) return;
    await send({ type: "popup_set_master", enabled: !state.masterEnabled });
    await refresh();
  })();
});
$("pause").addEventListener("click", () => {
  void (async () => {
    await send({ type: "popup_set_master", enabled: false });
    await refresh();
  })();
});
void refresh();
//# sourceMappingURL=popup.js.map
