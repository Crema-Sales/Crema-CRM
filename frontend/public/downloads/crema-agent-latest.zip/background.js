// src/background/ws-client.ts
var PING_INTERVAL_MS = 25e3;
var PONG_TIMEOUT_MS = 75e3;
var BACKOFF_LADDER_MS = [1e3, 2e3, 4e3, 8e3, 16e3, 32e3];
var BACKOFF_CAP_MS = 6e4;
var JITTER = 0.2;
var CLOSE_UNAUTHORIZED = 4401;
var CLOSE_FORBIDDEN = 4403;
var TERMINAL_CLOSE_CODES = /* @__PURE__ */ new Set([CLOSE_UNAUTHORIZED, CLOSE_FORBIDDEN]);
var AgentSocket = class {
  constructor(getConfig) {
    this.getConfig = getConfig;
  }
  ws = null;
  handlers = /* @__PURE__ */ new Set();
  pingTimer = null;
  pongWatchdog = null;
  reconnectTimer = null;
  backoffStep = 0;
  lastPongAt = 0;
  explicitlyClosed = false;
  statusListeners = /* @__PURE__ */ new Set();
  currentStatus = "idle";
  onMessage(handler) {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }
  onStatus(listener) {
    this.statusListeners.add(listener);
    listener(this.currentStatus);
    return () => this.statusListeners.delete(listener);
  }
  status() {
    return this.currentStatus;
  }
  isOpen() {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }
  async connect() {
    this.explicitlyClosed = false;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    this.cancelReconnect();
    let cfg;
    try {
      cfg = await this.getConfig();
    } catch (err) {
      console.warn("[agent] config unavailable, deferring connect:", err);
      this.scheduleReconnect();
      return;
    }
    if (!cfg.baseUrl || !cfg.repId || !cfg.jwt) {
      console.warn("[agent] config incomplete; not connecting");
      this.setStatus("idle");
      return;
    }
    const base = cfg.baseUrl.replace(/^http(s?):/i, (_, s) => `ws${s}:`).replace(/\/+$/, "");
    const url = `${base}/agents/${encodeURIComponent(cfg.repId)}/ws?token=${encodeURIComponent(cfg.jwt)}`;
    this.setStatus("connecting");
    let ws;
    try {
      ws = new WebSocket(url);
    } catch (err) {
      console.warn("[agent] WebSocket construct failed:", err);
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;
    ws.addEventListener("open", () => {
      console.log("[agent] connected");
      this.backoffStep = 0;
      this.lastPongAt = Date.now();
      this.setStatus("open");
      this.startHeartbeat();
    });
    ws.addEventListener("message", (ev) => {
      const data = typeof ev.data === "string" ? ev.data : "";
      if (!data) return;
      let parsed;
      try {
        parsed = JSON.parse(data);
      } catch {
        console.warn("[agent] non-JSON frame dropped");
        return;
      }
      if (parsed && typeof parsed === "object" && parsed.type === "pong") {
        this.lastPongAt = Date.now();
        return;
      }
      for (const h of this.handlers) {
        try {
          void h(parsed);
        } catch (err) {
          console.error("[agent] handler threw:", err);
        }
      }
    });
    ws.addEventListener("close", (ev) => {
      console.log("[agent] disconnected", ev.code, ev.reason);
      this.cleanupSocket();
      this.setStatus("closed");
      if (TERMINAL_CLOSE_CODES.has(ev.code)) {
        const reason = ev.code === CLOSE_UNAUTHORIZED ? "token rejected" : "rep forbidden";
        console.error(
          `[agent] terminal close ${ev.code} (${reason}). Wiping JWT \u2014 rep must re-auth at cremasales.com.`
        );
        chrome.storage.local.remove(["agentJwt", "agentRepId"]).catch((err) => {
          console.warn("[agent] failed to clear stored credentials:", err);
        });
        this.explicitlyClosed = true;
        return;
      }
      if (!this.explicitlyClosed) this.scheduleReconnect();
    });
    ws.addEventListener("error", () => {
    });
  }
  disconnect() {
    this.explicitlyClosed = true;
    this.cancelReconnect();
    this.cleanupSocket();
    if (this.ws) {
      try {
        this.ws.close(1e3, "client_disconnect");
      } catch {
      }
    }
    this.ws = null;
    this.setStatus("idle");
  }
  send(msg) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false;
    try {
      this.ws.send(JSON.stringify(msg));
      return true;
    } catch (err) {
      console.warn("[agent] send failed:", err);
      return false;
    }
  }
  startHeartbeat() {
    this.stopHeartbeat();
    this.pingTimer = setInterval(() => {
      const sent = this.send({ type: "ping" });
      if (!sent) return;
      if (Date.now() - this.lastPongAt > PONG_TIMEOUT_MS) {
        console.warn("[agent] pong watchdog tripped \u2014 forcing close");
        try {
          this.ws?.close(4e3, "pong_timeout");
        } catch {
        }
      }
    }, PING_INTERVAL_MS);
  }
  stopHeartbeat() {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    if (this.pongWatchdog) {
      clearTimeout(this.pongWatchdog);
      this.pongWatchdog = null;
    }
  }
  cleanupSocket() {
    this.stopHeartbeat();
  }
  scheduleReconnect() {
    if (this.explicitlyClosed) return;
    this.cancelReconnect();
    const base = BACKOFF_LADDER_MS[Math.min(this.backoffStep, BACKOFF_LADDER_MS.length - 1)] ?? BACKOFF_CAP_MS;
    const capped = Math.min(base, BACKOFF_CAP_MS);
    const jitter = capped * JITTER * (Math.random() * 2 - 1);
    const delay = Math.max(500, Math.round(capped + jitter));
    this.backoffStep += 1;
    console.log(`[agent] reconnecting in ${delay}ms (step ${this.backoffStep})`);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      void this.connect();
    }, delay);
  }
  cancelReconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }
  setStatus(s) {
    if (s === this.currentStatus) return;
    this.currentStatus = s;
    for (const l of this.statusListeners) {
      try {
        l(s);
      } catch (err) {
        console.error("[agent] status listener threw:", err);
      }
    }
  }
};
async function readAgentConfig() {
  const out = await chrome.storage.local.get(["agentBaseUrl", "agentRepId", "agentJwt"]);
  return {
    baseUrl: typeof out.agentBaseUrl === "string" ? out.agentBaseUrl : "",
    repId: typeof out.agentRepId === "string" ? out.agentRepId : "",
    jwt: typeof out.agentJwt === "string" ? out.agentJwt : ""
  };
}

// src/background/toggle.ts
var STORAGE_KEY = "agentEnabled";
var COLOR_ON = "#16a34a";
var COLOR_REC = "#d97706";
var COLOR_DRV = "#2563eb";
var ICON_ON = "icons/agent-on-128.png";
var ICON_OFF = "icons/agent-off-128.png";
var RECORDING_DECAY_MS = 4e3;
var DRIVING_DECAY_MS = 2e4;
var activity = "idle";
var decayTimer = null;
async function getEnabled() {
  const out = await chrome.storage.local.get(STORAGE_KEY);
  return out[STORAGE_KEY] !== false;
}
async function setEnabled(value, socket2) {
  await chrome.storage.local.set({ [STORAGE_KEY]: value });
  if (!value) activity = "idle";
  await paint(value);
  if (socket2) socket2.send({ type: "toggle", enabled: value });
}
function getActivity() {
  return activity;
}
async function setActivity(next) {
  if (decayTimer) {
    clearTimeout(decayTimer);
    decayTimer = null;
  }
  activity = next;
  const enabled = await getEnabled();
  await paint(enabled);
  if (next !== "idle" && enabled) {
    const ms = next === "recording" ? RECORDING_DECAY_MS : DRIVING_DECAY_MS;
    decayTimer = setTimeout(() => {
      decayTimer = null;
      activity = "idle";
      void getEnabled().then((e) => paint(e));
    }, ms);
  }
}
async function applyVisualState(enabled) {
  await paint(enabled);
}
async function paint(enabled) {
  const icon = enabled ? ICON_ON : ICON_OFF;
  try {
    await chrome.action.setIcon({ path: { 16: icon, 32: icon, 48: icon, 128: icon } });
  } catch (err) {
    console.warn("[toggle] setIcon failed:", err);
  }
  let badge = "";
  let badgeColor = COLOR_ON;
  let title = "Crema Sales Agent \u2014 Off";
  if (enabled) {
    title = "Crema Sales Agent \u2014 On";
    if (activity === "recording") {
      badge = "REC";
      badgeColor = COLOR_REC;
      title = "Crema Sales Agent \u2014 Recording activity";
    } else if (activity === "driving") {
      badge = "DRV";
      badgeColor = COLOR_DRV;
      title = "Crema Sales Agent \u2014 Driving the browser";
    }
  }
  try {
    await chrome.action.setBadgeText({ text: badge });
    if (badge) await chrome.action.setBadgeBackgroundColor({ color: badgeColor });
    await chrome.action.setTitle({ title });
  } catch (err) {
    console.warn("[toggle] badge/title failed:", err);
  }
}

// src/background/dispatch.ts
var SNAPSHOT_DEFAULT_CAP = 1e6;
var EVAL_ALLOWLIST = {
  page_title: async (_args, tabId) => {
    const out = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => document.title
    });
    return { value: out[0]?.result ?? "" };
  },
  page_url: async (_args, tabId) => {
    const tab = await chrome.tabs.get(tabId);
    return { value: tab.url ?? "" };
  }
};
async function dispatch(cmd) {
  try {
    switch (cmd.type) {
      case "navigate":
        return ok(cmd.id, await cmdNavigate(cmd.params ?? {}));
      case "click":
        return ok(cmd.id, await cmdClick(cmd.params ?? {}));
      case "type":
        return ok(cmd.id, await cmdType(cmd.params ?? {}));
      case "snapshot":
        return ok(cmd.id, await cmdSnapshot(cmd.params ?? {}));
      case "screenshot":
        return ok(cmd.id, await cmdScreenshot(cmd.params ?? {}));
      case "eval":
        return ok(cmd.id, await cmdEval(cmd.params ?? {}));
      default:
        return fail(cmd.id, "internal", `unknown command: ${cmd.type}`);
    }
  } catch (err) {
    const code = err.code;
    const msg = err.message ?? String(err);
    console.warn(`[dispatch] ${cmd.type} failed:`, err);
    return fail(cmd.id, code ?? "internal", msg);
  }
}
function ok(id, result) {
  return { id, ok: true, result };
}
function fail(id, error, message) {
  if (message) return { id, ok: false, error, result: { message } };
  return { id, ok: false, error };
}
function str(p, k) {
  const v = p[k];
  return typeof v === "string" ? v : void 0;
}
function num(p, k) {
  const v = p[k];
  return typeof v === "number" && Number.isFinite(v) ? v : void 0;
}
function bool(p, k) {
  const v = p[k];
  return typeof v === "boolean" ? v : void 0;
}
var CmdError = class extends Error {
  constructor(code, message) {
    super(message ?? code);
    this.code = code;
  }
};
async function getTab(tabId) {
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  try {
    return await chrome.tabs.get(tabId);
  } catch {
    throw new CmdError("tab_not_found", `tab ${tabId} not found`);
  }
}
async function cmdNavigate(p) {
  const url = str(p, "url");
  if (!url) throw new CmdError("internal", "url required");
  let tabId = num(p, "tabId");
  let tab;
  if (tabId === void 0) {
    tab = await chrome.tabs.create({ url });
    tabId = tab.id;
  } else {
    tab = await getTab(tabId);
    await chrome.tabs.update(tabId, { url });
  }
  if (tabId === void 0) throw new CmdError("internal", "tab creation returned no id");
  await waitForLoad(tabId, 3e4);
  return { tabId };
}
function waitForLoad(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new CmdError("timeout", `tab ${tabId} load timed out`));
    }, timeoutMs);
    const listener = (updatedId, info) => {
      if (updatedId !== tabId) return;
      if (info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}
async function cmdClick(p) {
  const tabId = num(p, "tabId");
  const selector = str(p, "selector");
  const cdp = bool(p, "cdp") ?? false;
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  if (!selector) throw new CmdError("internal", "selector required");
  await getTab(tabId);
  if (cdp) return clickViaCdp(tabId, selector);
  const out = await chrome.scripting.executeScript({
    target: { tabId },
    args: [selector],
    func: (sel) => {
      const el = document.querySelector(sel);
      if (!el) return { found: false };
      el.click();
      return { found: true };
    }
  });
  const result = out[0]?.result;
  if (!result?.found) throw new CmdError("selector_not_found", selector);
  return {};
}
async function cmdType(p) {
  const tabId = num(p, "tabId");
  const selector = str(p, "selector");
  const text = str(p, "text") ?? "";
  const cdp = bool(p, "cdp") ?? false;
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  if (!selector) throw new CmdError("internal", "selector required");
  await getTab(tabId);
  if (cdp) return typeViaCdp(tabId, selector, text);
  const out = await chrome.scripting.executeScript({
    target: { tabId },
    args: [selector, text],
    func: (sel, value) => {
      const el = document.querySelector(sel);
      if (!el) return { found: false };
      el.focus?.();
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        const setter = Object.getOwnPropertyDescriptor(
          el instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype,
          "value"
        )?.set;
        if (setter) setter.call(el, value);
        else el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el.isContentEditable) {
        el.textContent = value;
        el.dispatchEvent(new InputEvent("input", { bubbles: true }));
      } else {
        return { found: false };
      }
      return { found: true };
    }
  });
  const result = out[0]?.result;
  if (!result?.found) throw new CmdError("selector_not_found", selector);
  return {};
}
async function cmdSnapshot(p) {
  const tabId = num(p, "tabId");
  const maxBytes = num(p, "max_bytes") ?? SNAPSHOT_DEFAULT_CAP;
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  await getTab(tabId);
  const out = await chrome.scripting.executeScript({
    target: { tabId },
    args: [maxBytes],
    func: (cap) => {
      const html2 = document.documentElement.outerHTML;
      return html2.length > cap ? html2.slice(0, cap) : html2;
    }
  });
  const html = out[0]?.result ?? "";
  return { html };
}
async function cmdScreenshot(p) {
  const tabId = num(p, "tabId");
  const format = str(p, "format") ?? "png";
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  const tab = await getTab(tabId);
  if (tab.windowId === void 0) throw new CmdError("internal", "tab missing windowId");
  const data_url = await chrome.tabs.captureVisibleTab(tab.windowId, { format });
  return { data_url };
}
async function cmdEval(p) {
  const tabId = num(p, "tabId");
  const name = str(p, "name");
  const args = p.args && typeof p.args === "object" ? p.args : {};
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  if (!name) throw new CmdError("eval_not_allowlisted", "name required");
  const fn = EVAL_ALLOWLIST[name];
  if (!fn) throw new CmdError("eval_not_allowlisted", name);
  return fn(args, tabId);
}
async function clickViaCdp(tabId, selector) {
  await chrome.debugger.attach({ tabId }, "1.3");
  try {
    const rect = await resolveRect(tabId, selector);
    const x = rect.x + rect.width / 2;
    const y = rect.y + rect.height / 2;
    await sendCdp(tabId, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x,
      y,
      button: "left",
      clickCount: 1
    });
    await sendCdp(tabId, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x,
      y,
      button: "left",
      clickCount: 1
    });
    return {};
  } finally {
    await safeDetach(tabId);
  }
}
async function typeViaCdp(tabId, selector, text) {
  await chrome.debugger.attach({ tabId }, "1.3");
  try {
    await sendCdp(tabId, "Runtime.evaluate", {
      expression: `(function(){var el=document.querySelector(${JSON.stringify(selector)});if(el&&el.focus)el.focus();return !!el;})()`,
      returnByValue: true
    });
    for (const ch of text) {
      await sendCdp(tabId, "Input.dispatchKeyEvent", { type: "keyDown", text: ch });
      await sendCdp(tabId, "Input.dispatchKeyEvent", { type: "keyUp", text: ch });
    }
    return {};
  } finally {
    await safeDetach(tabId);
  }
}
async function resolveRect(tabId, selector) {
  const res = await sendCdp(tabId, "Runtime.evaluate", {
    expression: `(function(){var el=document.querySelector(${JSON.stringify(selector)});if(!el)return null;var r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};})()`,
    returnByValue: true
  });
  const rect = res.result?.value;
  if (!rect) throw new CmdError("selector_not_found", selector);
  return rect;
}
function sendCdp(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new CmdError("internal", err.message));
      else resolve(result);
    });
  });
}
async function safeDetach(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
  }
}

// src/background/validate.ts
var UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
var LOWERCASE_EMAIL = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
function isValidRepId(repId) {
  if (repId.length < 3 || repId.length > 254) return false;
  return UUID_V4.test(repId) || LOWERCASE_EMAIL.test(repId);
}
var ALLOWED_BASE_URLS = /* @__PURE__ */ new Set([
  "wss://ctrl-alt-elite-agent.smashlabs.workers.dev"
]);
function isAllowedOrigin(protocol, hostname, origin) {
  if (protocol === "wss:") {
    if (ALLOWED_BASE_URLS.has(origin)) return true;
    if (hostname === "cremasales.com") return true;
    if (hostname.endsWith(".cremasales.com")) return true;
    return false;
  }
  if (protocol === "ws:") {
    if (hostname === "localhost" || hostname === "127.0.0.1") return true;
    return false;
  }
  return false;
}
function normalizeBaseUrl(input) {
  if (typeof input !== "string" || !input) return null;
  let s = input.trim();
  s = s.replace(/^http(s?):/i, (_, x) => `ws${x}:`);
  s = s.replace(/\/+$/, "");
  try {
    const u = new URL(s);
    if (u.pathname !== "/" && u.pathname !== "") return null;
    if (u.search || u.hash) return null;
    if (u.username || u.password) return null;
    return `${u.protocol}//${u.host}`;
  } catch {
    return null;
  }
}
function isAllowedBaseUrl(input) {
  const norm = normalizeBaseUrl(input);
  if (norm === null) return false;
  try {
    const u = new URL(norm);
    return isAllowedOrigin(u.protocol, u.hostname, norm);
  } catch {
    return false;
  }
}

// src/background/dedup.ts
var CAPACITY = 256;
var order = [];
var cache = /* @__PURE__ */ new Map();
function rememberAck(id, resp) {
  if (cache.has(id)) {
    const idx = order.indexOf(id);
    if (idx >= 0) order.splice(idx, 1);
  } else if (order.length >= CAPACITY) {
    const evict = order.shift();
    if (evict !== void 0) cache.delete(evict);
  }
  cache.set(id, resp);
  order.push(id);
}
function recallAck(id) {
  return cache.get(id);
}

// src/background/sites.ts
var SITES = [
  {
    id: "gmail",
    label: "Gmail",
    matches: ["https://mail.google.com/*"],
    hostSuffixes: ["mail.google.com"]
  },
  {
    id: "outlook",
    label: "Outlook",
    matches: [
      "https://outlook.office.com/*",
      "https://outlook.office365.com/*",
      "https://outlook.live.com/*"
    ],
    hostSuffixes: ["outlook.office.com", "outlook.office365.com", "outlook.live.com"]
  },
  {
    id: "linkedin",
    label: "LinkedIn",
    matches: ["https://www.linkedin.com/*"],
    hostSuffixes: ["linkedin.com"]
  },
  {
    id: "teams",
    label: "Microsoft Teams",
    matches: ["https://teams.microsoft.com/*"],
    hostSuffixes: ["teams.microsoft.com"]
  }
];
var ALLOWLIST_KEY = "siteAllowlist";
async function getAllowlist() {
  const out = await chrome.storage.local.get(ALLOWLIST_KEY);
  const stored = out[ALLOWLIST_KEY] ?? {};
  const full = {};
  for (const s of SITES) full[s.id] = stored[s.id] !== false;
  return full;
}
async function setSiteAllowed(id, enabled) {
  const current = await getAllowlist();
  current[id] = enabled;
  await chrome.storage.local.set({ [ALLOWLIST_KEY]: current });
}
function siteForUrl(url) {
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return void 0;
  }
  return SITES.find((s) => s.hostSuffixes.some((h) => host === h || host.endsWith(`.${h}`)));
}

// src/background/capture-rules.ts
var DEFAULT_RULES = [
  {
    id: "gmail.email_sent",
    site: "gmail",
    kind: "email_sent",
    body: "form",
    // Gmail's compose-send RPC: /mail/u/<n>/...&act=sm  (send message).
    match: { method: "POST", urlIncludes: ["mail.google.com", "act=sm"] },
    extract: {
      contactEmail: { path: "to", regex: "[\\w.+-]+@[\\w-]+\\.[\\w.-]+" },
      subject: { path: "subject" },
      preview: { path: "body" }
    }
  },
  {
    id: "outlook.email_sent",
    site: "outlook",
    kind: "email_sent",
    body: "json",
    // OWA send: the Substrate/OWA mail API exposes a SendMessage-style action.
    match: { method: "POST", urlIncludes: ["/ows/", "Send"] },
    extract: {
      contactEmail: {
        path: "Body.Message.ToRecipients.0.EmailAddress.Address"
      },
      contactName: { path: "Body.Message.ToRecipients.0.EmailAddress.Name" },
      subject: { path: "Body.Message.Subject" }
    }
  },
  {
    id: "linkedin.linkedin_message",
    site: "linkedin",
    kind: "linkedin_message",
    body: "json",
    // Voyager messaging send.
    match: {
      method: "POST",
      urlIncludes: ["linkedin.com/voyager/api", "messaging"]
    },
    extract: {
      preview: { path: "message.body.text" },
      contactProfileUrl: { path: "hostRecipientUrns.0" }
    }
  },
  {
    id: "linkedin.linkedin_comment",
    site: "linkedin",
    kind: "linkedin_comment",
    body: "json",
    // Voyager comment creation under the social/feed surface.
    match: {
      method: "POST",
      urlIncludes: ["linkedin.com/voyager/api", "socialActions"],
      urlRegex: "comments"
    },
    extract: {
      preview: { path: "comment.values.0.value.text" }
    }
  }
];
var RULES_KEY = "captureRules";
var cachedRules = DEFAULT_RULES;
function getCaptureRules() {
  return cachedRules;
}
function applyStored(stored) {
  if (Array.isArray(stored) && stored.length > 0) {
    cachedRules = stored;
  } else {
    cachedRules = DEFAULT_RULES;
  }
}
async function initCaptureRules() {
  try {
    const out = await chrome.storage.local.get(RULES_KEY);
    applyStored(out[RULES_KEY]);
  } catch (err) {
    console.warn("[crema-capture] failed to load capture rules:", err);
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[RULES_KEY]) return;
    applyStored(changes[RULES_KEY].newValue);
    console.log(`[crema-capture] capture rules hot-reloaded (${cachedRules.length} rules)`);
  });
}

// src/content/util.ts
function hash(input) {
  let h = 5381;
  for (let i = 0; i < input.length; i++) h = (h << 5) + h + input.charCodeAt(i) | 0;
  return (h >>> 0).toString(36);
}

// src/background/net-capture.ts
var masterEnabled = true;
var allowlist = null;
function siteAllowed(id) {
  return allowlist ? allowlist[id] : true;
}
async function refreshGateCache() {
  try {
    const [{ agentEnabled }, list] = await Promise.all([
      chrome.storage.local.get("agentEnabled"),
      getAllowlist()
    ]);
    masterEnabled = agentEnabled !== false;
    allowlist = list;
  } catch (err) {
    console.warn("[crema-capture] gate cache refresh failed:", err);
  }
}
function decodeRaw(raw) {
  if (!raw || raw.length === 0) return "";
  const decoder = new TextDecoder();
  let out = "";
  for (const part of raw) {
    if (part.bytes) out += decoder.decode(part.bytes, { stream: true });
  }
  return out + decoder.decode();
}
function parseBody(details, encoding) {
  const rb = details.requestBody;
  if (!rb) return null;
  if (encoding === "form") {
    if (rb.formData) {
      const out2 = {};
      for (const [k, v] of Object.entries(rb.formData)) out2[k] = v;
      return out2;
    }
    const text2 = decodeRaw(rb.raw);
    if (!text2) return null;
    const out = {};
    for (const [k, v] of new URLSearchParams(text2)) {
      const prev = out[k];
      if (prev === void 0) out[k] = v;
      else if (Array.isArray(prev)) prev.push(v);
      else out[k] = [prev, v];
    }
    return out;
  }
  const text = decodeRaw(rb.raw);
  if (!text) return null;
  try {
    const parsed = JSON.parse(text);
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}
function getPath(root, path) {
  let cur = root;
  for (const key of path.split(".")) {
    if (cur == null) return void 0;
    if (Array.isArray(cur)) {
      const idx = Number(key);
      cur = Number.isInteger(idx) ? cur[idx] : void 0;
    } else if (typeof cur === "object") {
      cur = cur[key];
    } else {
      return void 0;
    }
  }
  return cur;
}
function extractField(body, spec) {
  let value = getPath(body, spec.path);
  if (Array.isArray(value)) value = value[0];
  if (value == null) return void 0;
  const str2 = typeof value === "string" ? value : String(value);
  if (!str2) return void 0;
  if (spec.regex) {
    try {
      const m = str2.match(new RegExp(spec.regex));
      return m ? m[1] ?? m[0] : void 0;
    } catch {
      return void 0;
    }
  }
  return str2;
}
function matchesRule(rule, details) {
  if (rule.match.method.toUpperCase() !== (details.method ?? "").toUpperCase()) return false;
  const url = details.url;
  if (rule.match.urlIncludes && !rule.match.urlIncludes.every((s) => url.includes(s))) {
    return false;
  }
  if (rule.match.urlRegex) {
    try {
      if (!new RegExp(rule.match.urlRegex).test(url)) return false;
    } catch {
      return false;
    }
  }
  return true;
}
function buildEvent(rule, body, url) {
  const ex = rule.extract;
  const email = ex.contactEmail && extractField(body, ex.contactEmail)?.toLowerCase();
  const name = ex.contactName && extractField(body, ex.contactName);
  const profileUrl = ex.contactProfileUrl && extractField(body, ex.contactProfileUrl);
  const subject = ex.subject && extractField(body, ex.subject);
  const preview = ex.preview && extractField(body, ex.preview);
  if (!email && !name && !profileUrl && !subject) {
    console.warn(
      `[crema-capture] rule '${rule.id}' matched ${url} but extraction was empty \u2014 needs tuning (TODO A1)`
    );
    return null;
  }
  const contact = email || name || profileUrl ? { email, name, profileUrl } : void 0;
  return {
    kind: rule.kind,
    site: rule.site,
    occurredAt: Date.now(),
    contact,
    subject,
    preview,
    url,
    // Network-source key. Cross-source coalescing with the DOM adapters is the
    // service worker's job (`index.ts`), keyed on content not on this string.
    dedupeKey: `${rule.site}:${rule.kind}:net:${hash(
      (email ?? name ?? profileUrl ?? "") + (subject ?? preview ?? "")
    )}:${Math.floor(Date.now() / 2e3)}`
  };
}
function handleRequest(forward, details) {
  if (!masterEnabled) return;
  const site = siteForUrl(details.url);
  if (!site || !siteAllowed(site.id)) return;
  for (const rule of getCaptureRules()) {
    if (rule.site !== site.id || !matchesRule(rule, details)) continue;
    const body = parseBody(details, rule.body);
    if (!body) continue;
    const event = buildEvent(rule, body, details.url);
    if (event) {
      console.log(`[crema-capture] network hit: ${rule.id}`);
      forward(event, "network");
    }
    return;
  }
}
function initNetCapture(forward) {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      try {
        handleRequest(forward, details);
      } catch (err) {
        console.warn("[crema-capture] net-capture handler threw:", err);
      }
    },
    { urls: SITES.flatMap((s) => s.matches), types: ["xmlhttprequest"] },
    ["requestBody"]
  );
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.agentEnabled || changes.siteAllowlist)) {
      void refreshGateCache();
    }
  });
  void refreshGateCache();
  console.log("[crema-capture] network intent router active");
}

// src/background/index.ts
console.log("[crema-agent] service worker boot");
var socket = new AgentSocket(readAgentConfig);
socket.onStatus(async (s) => {
  console.log("[crema-agent] status:", s);
  if (s === "open") {
    const enabled = await getEnabled();
    socket.send({ type: "online", enabled });
  }
});
socket.onMessage(async (msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (!m.id || !m.type || m.type === "pong") return;
  const cached = recallAck(m.id);
  if (cached) {
    console.log(`[crema-agent] dedup hit for ${m.id} \u2014 replaying cached ack`);
    socket.send(cached);
    return;
  }
  const enabled = await getEnabled();
  let resp;
  if (!enabled) {
    resp = { id: m.id, ok: false, error: "rep_disabled" };
  } else {
    await setActivity("driving");
    try {
      resp = await dispatch(m);
    } finally {
      await setActivity("idle");
    }
  }
  rememberAck(m.id, resp);
  socket.send(resp);
});
void applyVisualState(true);
void (async () => {
  await applyVisualState(await getEnabled());
  await socket.connect();
})();
initNetCapture((event, source) => void forwardActivityEvent(event, source));
void initCaptureRules();
var KEEPALIVE_ALARM = "agent-keepalive";
chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === KEEPALIVE_ALARM && !socket.isOpen()) {
    void socket.connect();
  }
});
chrome.runtime.onStartup.addListener(() => {
  console.log("[crema-agent] onStartup");
  void socket.connect();
});
var DEFAULT_ONBOARD_URL = "https://cremasales.com/extension/onboard";
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[crema-agent] onInstalled reason=", details.reason);
  void socket.connect();
  if (details.reason === "install") {
    const { onboardUrl } = await chrome.storage.local.get("onboardUrl");
    const base = typeof onboardUrl === "string" && onboardUrl ? onboardUrl : DEFAULT_ONBOARD_URL;
    const installId = crypto.randomUUID();
    const url = `${base}${base.includes("?") ? "&" : "?"}install_id=${encodeURIComponent(installId)}`;
    try {
      await chrome.tabs.create({ url });
    } catch (err) {
      console.warn("[crema-agent] failed to open onboarding tab:", err);
    }
  }
});
var ALLOWED_HANDOFF_ORIGINS = [
  /^https:\/\/cremasales\.com$/,
  /^https:\/\/[a-z0-9-]+\.cremasales\.com$/,
  /^http:\/\/localhost(?::\d+)?$/
];
var JWT_SHAPE = /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/;
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  (async () => {
    const origin = sender.origin ?? "";
    if (!ALLOWED_HANDOFF_ORIGINS.some((re) => re.test(origin))) {
      console.warn("[crema-agent] handoff rejected: untrusted origin:", origin);
      sendResponse({ ok: false, error: "untrusted_origin" });
      return;
    }
    if (!message || typeof message !== "object") {
      sendResponse({ ok: false, error: "invalid_payload" });
      return;
    }
    const m = message;
    if (m.type !== "agent_handoff") {
      sendResponse({ ok: false, error: "unknown_type" });
      return;
    }
    const repId = typeof m.repId === "string" ? m.repId : "";
    const jwt = typeof m.jwt === "string" ? m.jwt : "";
    const baseUrl = typeof m.baseUrl === "string" ? m.baseUrl : "";
    if (!repId || !jwt || !baseUrl) {
      sendResponse({ ok: false, error: "missing_fields" });
      return;
    }
    if (!isValidRepId(repId)) {
      sendResponse({ ok: false, error: "malformed_repId" });
      return;
    }
    if (!JWT_SHAPE.test(jwt)) {
      sendResponse({ ok: false, error: "malformed_jwt" });
      return;
    }
    if (!isAllowedBaseUrl(baseUrl)) {
      console.warn("[crema-agent] handoff rejected: baseUrl not allowlisted:", baseUrl);
      sendResponse({ ok: false, error: "baseUrl_not_allowed" });
      return;
    }
    const normalized = normalizeBaseUrl(baseUrl) ?? baseUrl;
    await chrome.storage.local.set({
      agentRepId: repId,
      agentJwt: jwt,
      agentBaseUrl: normalized
    });
    console.log("[crema-agent] agent_handoff persisted for rep", repId);
    void socket.connect();
    const enabled = await getEnabled();
    sendResponse({ ok: true, enabled });
  })();
  return true;
});
var ACTIVITY_SEEN_CAP = 512;
var activitySeen = /* @__PURE__ */ new Set();
function activitySeenAdd(key) {
  activitySeen.add(key);
  if (activitySeen.size > ACTIVITY_SEEN_CAP) {
    const oldest = activitySeen.values().next().value;
    if (oldest !== void 0) activitySeen.delete(oldest);
  }
}
var COALESCE_WINDOW_MS = 15e3;
var coalesceSeen = /* @__PURE__ */ new Map();
function coalesceKey(ev) {
  if (ev.kind === "email_received") return null;
  const who = ev.contact?.email || ev.contact?.profileUrl || ev.contact?.name || "";
  return `${ev.kind}|${who}|${hash(`${ev.subject ?? ""}|${ev.preview ?? ""}`)}`;
}
function coalesceHit(key) {
  const now = Date.now();
  for (const [k, t] of coalesceSeen) {
    if (now - t > COALESCE_WINDOW_MS) coalesceSeen.delete(k);
  }
  const last = coalesceSeen.get(key);
  return last !== void 0 && now - last < COALESCE_WINDOW_MS;
}
async function forwardActivityEvent(ev, source) {
  if (!ev || typeof ev !== "object") return { ok: false, error: "invalid_event" };
  const event = ev;
  const dk = typeof event.dedupeKey === "string" ? event.dedupeKey : null;
  if (dk && activitySeen.has(dk)) return { ok: true, deduped: true };
  const ck = coalesceKey(event);
  if (ck && coalesceHit(ck)) return { ok: true, deduped: true };
  if (!await getEnabled()) return { ok: false, error: "rep_disabled" };
  if (dk) activitySeenAdd(dk);
  if (ck) coalesceSeen.set(ck, Date.now());
  void setActivity("recording");
  const delivered = socket.send({ type: "activity_event", event, ts: Date.now() });
  console.log(`[crema-agent] activity_event (${source}): ${event.kind} delivered=${delivered}`);
  return { ok: true, delivered };
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    const m = message ?? {};
    switch (m.type) {
      case "activity_event": {
        sendResponse(await forwardActivityEvent(m.event, "dom"));
        return;
      }
      case "popup_get_state": {
        const [enabled, allowlist2, cfg] = await Promise.all([
          getEnabled(),
          getAllowlist(),
          readAgentConfig()
        ]);
        sendResponse({
          ok: true,
          masterEnabled: enabled,
          connection: socket.status(),
          repId: cfg.repId || null,
          activity: getActivity(),
          sites: SITES.map((s) => ({ id: s.id, label: s.label, allowed: allowlist2[s.id] }))
        });
        return;
      }
      case "popup_set_master": {
        await setEnabled(m.enabled === true, socket);
        sendResponse({ ok: true });
        return;
      }
      case "popup_set_site": {
        const id = m.siteId;
        if (!SITES.some((s) => s.id === id)) {
          sendResponse({ ok: false, error: "unknown_site" });
          return;
        }
        await setSiteAllowed(id, m.enabled === true);
        sendResponse({ ok: true });
        return;
      }
      default:
        sendResponse({ ok: false, error: "unknown_type" });
    }
  })();
  return true;
});
globalThis.__cremaAgent = { socket };
//# sourceMappingURL=background.js.map
