// src/background/ws-client.ts
var PING_INTERVAL_MS = 25e3;
var PONG_TIMEOUT_MS = 75e3;
var BACKOFF_LADDER_MS = [1e3, 2e3, 4e3, 8e3, 16e3, 32e3];
var BACKOFF_CAP_MS = 6e4;
var JITTER = 0.2;
var CLOSE_UNAUTHORIZED = 4401;
var CLOSE_FORBIDDEN = 4403;
var TERMINAL_CLOSE_CODES = /* @__PURE__ */ new Set([CLOSE_UNAUTHORIZED, CLOSE_FORBIDDEN]);
var AgentSocket = class {
  constructor(getConfig) {
    this.getConfig = getConfig;
  }
  ws = null;
  handlers = /* @__PURE__ */ new Set();
  pingTimer = null;
  pongWatchdog = null;
  reconnectTimer = null;
  backoffStep = 0;
  lastPongAt = 0;
  explicitlyClosed = false;
  statusListeners = /* @__PURE__ */ new Set();
  currentStatus = "idle";
  onMessage(handler) {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }
  onStatus(listener) {
    this.statusListeners.add(listener);
    listener(this.currentStatus);
    return () => this.statusListeners.delete(listener);
  }
  status() {
    return this.currentStatus;
  }
  isOpen() {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }
  async connect() {
    this.explicitlyClosed = false;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    this.cancelReconnect();
    let cfg;
    try {
      cfg = await this.getConfig();
    } catch (err) {
      console.warn("[agent] config unavailable, deferring connect:", err);
      this.scheduleReconnect();
      return;
    }
    if (!cfg.baseUrl || !cfg.repId || !cfg.jwt) {
      console.warn("[agent] config incomplete; not connecting");
      this.setStatus("idle");
      return;
    }
    const base = cfg.baseUrl.replace(/^http(s?):/i, (_, s) => `ws${s}:`).replace(/\/+$/, "");
    const url = `${base}/agents/${encodeURIComponent(cfg.repId)}/ws?token=${encodeURIComponent(cfg.jwt)}`;
    this.setStatus("connecting");
    let ws;
    try {
      ws = new WebSocket(url);
    } catch (err) {
      console.warn("[agent] WebSocket construct failed:", err);
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;
    ws.addEventListener("open", () => {
      console.log("[agent] connected");
      this.backoffStep = 0;
      this.lastPongAt = Date.now();
      this.setStatus("open");
      this.startHeartbeat();
    });
    ws.addEventListener("message", (ev) => {
      const data = typeof ev.data === "string" ? ev.data : "";
      if (!data) return;
      let parsed;
      try {
        parsed = JSON.parse(data);
      } catch {
        console.warn("[agent] non-JSON frame dropped");
        return;
      }
      if (parsed && typeof parsed === "object" && parsed.type === "pong") {
        this.lastPongAt = Date.now();
        return;
      }
      for (const h of this.handlers) {
        try {
          void h(parsed);
        } catch (err) {
          console.error("[agent] handler threw:", err);
        }
      }
    });
    ws.addEventListener("close", (ev) => {
      console.log("[agent] disconnected", ev.code, ev.reason);
      this.cleanupSocket();
      this.setStatus("closed");
      if (TERMINAL_CLOSE_CODES.has(ev.code)) {
        const reason = ev.code === CLOSE_UNAUTHORIZED ? "token rejected" : "rep forbidden";
        console.error(
          `[agent] terminal close ${ev.code} (${reason}). Wiping JWT \u2014 rep must re-auth at cremasales.com.`
        );
        chrome.storage.local.remove(["agentJwt", "agentRepId"]).catch((err) => {
          console.warn("[agent] failed to clear stored credentials:", err);
        });
        this.explicitlyClosed = true;
        return;
      }
      if (!this.explicitlyClosed) this.scheduleReconnect();
    });
    ws.addEventListener("error", () => {
    });
  }
  disconnect() {
    this.explicitlyClosed = true;
    this.cancelReconnect();
    this.cleanupSocket();
    if (this.ws) {
      try {
        this.ws.close(1e3, "client_disconnect");
      } catch {
      }
    }
    this.ws = null;
    this.setStatus("idle");
  }
  send(msg) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false;
    try {
      this.ws.send(JSON.stringify(msg));
      return true;
    } catch (err) {
      console.warn("[agent] send failed:", err);
      return false;
    }
  }
  startHeartbeat() {
    this.stopHeartbeat();
    this.pingTimer = setInterval(() => {
      const sent = this.send({ type: "ping" });
      if (!sent) return;
      if (Date.now() - this.lastPongAt > PONG_TIMEOUT_MS) {
        console.warn("[agent] pong watchdog tripped \u2014 forcing close");
        try {
          this.ws?.close(4e3, "pong_timeout");
        } catch {
        }
      }
    }, PING_INTERVAL_MS);
  }
  stopHeartbeat() {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    if (this.pongWatchdog) {
      clearTimeout(this.pongWatchdog);
      this.pongWatchdog = null;
    }
  }
  cleanupSocket() {
    this.stopHeartbeat();
  }
  scheduleReconnect() {
    if (this.explicitlyClosed) return;
    this.cancelReconnect();
    const base = BACKOFF_LADDER_MS[Math.min(this.backoffStep, BACKOFF_LADDER_MS.length - 1)] ?? BACKOFF_CAP_MS;
    const capped = Math.min(base, BACKOFF_CAP_MS);
    const jitter = capped * JITTER * (Math.random() * 2 - 1);
    const delay = Math.max(500, Math.round(capped + jitter));
    this.backoffStep += 1;
    console.log(`[agent] reconnecting in ${delay}ms (step ${this.backoffStep})`);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      void this.connect();
    }, delay);
  }
  cancelReconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }
  setStatus(s) {
    if (s === this.currentStatus) return;
    this.currentStatus = s;
    for (const l of this.statusListeners) {
      try {
        l(s);
      } catch (err) {
        console.error("[agent] status listener threw:", err);
      }
    }
  }
};
async function readAgentConfig() {
  const out = await chrome.storage.local.get(["agentBaseUrl", "agentRepId", "agentJwt"]);
  return {
    baseUrl: typeof out.agentBaseUrl === "string" ? out.agentBaseUrl : "",
    repId: typeof out.agentRepId === "string" ? out.agentRepId : "",
    jwt: typeof out.agentJwt === "string" ? out.agentJwt : ""
  };
}

// src/background/toggle.ts
var STORAGE_KEY = "agentEnabled";
var COLOR_ON = "#16a34a";
var ICON_ON = "icons/agent-on-128.png";
var ICON_OFF = "icons/agent-off-128.png";
async function getEnabled() {
  const out = await chrome.storage.local.get(STORAGE_KEY);
  return out[STORAGE_KEY] !== false;
}
async function setEnabled(value, socket2) {
  await chrome.storage.local.set({ [STORAGE_KEY]: value });
  await applyVisualState(value);
  if (socket2) socket2.send({ type: "toggle", enabled: value });
}
async function applyVisualState(enabled) {
  const icon = enabled ? ICON_ON : ICON_OFF;
  try {
    await chrome.action.setIcon({
      path: {
        16: icon,
        32: icon,
        48: icon,
        128: icon
      }
    });
  } catch (err) {
    console.warn("[toggle] setIcon failed:", err);
  }
  try {
    await chrome.action.setBadgeText({ text: enabled ? "ON" : "" });
    if (enabled) {
      await chrome.action.setBadgeBackgroundColor({ color: COLOR_ON });
    }
    await chrome.action.setTitle({ title: enabled ? "Crema Agent (ON)" : "Crema Agent (OFF)" });
  } catch (err) {
    console.warn("[toggle] badge/title failed:", err);
  }
}
function attachToggleListener(socket2) {
  chrome.action.onClicked.addListener(async () => {
    const current = await getEnabled();
    await setEnabled(!current, socket2);
    console.log("[toggle] toolbar click \u2192", !current);
  });
}

// src/background/dispatch.ts
var SNAPSHOT_DEFAULT_CAP = 1e6;
var EVAL_ALLOWLIST = {
  page_title: async (_args, tabId) => {
    const out = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => document.title
    });
    return { value: out[0]?.result ?? "" };
  },
  page_url: async (_args, tabId) => {
    const tab = await chrome.tabs.get(tabId);
    return { value: tab.url ?? "" };
  }
};
async function dispatch(cmd) {
  try {
    switch (cmd.type) {
      case "navigate":
        return ok(cmd.id, await cmdNavigate(cmd.params ?? {}));
      case "click":
        return ok(cmd.id, await cmdClick(cmd.params ?? {}));
      case "type":
        return ok(cmd.id, await cmdType(cmd.params ?? {}));
      case "snapshot":
        return ok(cmd.id, await cmdSnapshot(cmd.params ?? {}));
      case "screenshot":
        return ok(cmd.id, await cmdScreenshot(cmd.params ?? {}));
      case "eval":
        return ok(cmd.id, await cmdEval(cmd.params ?? {}));
      default:
        return fail(cmd.id, "internal", `unknown command: ${cmd.type}`);
    }
  } catch (err) {
    const code = err.code;
    const msg = err.message ?? String(err);
    console.warn(`[dispatch] ${cmd.type} failed:`, err);
    return fail(cmd.id, code ?? "internal", msg);
  }
}
function ok(id, result) {
  return { id, ok: true, result };
}
function fail(id, error, message) {
  if (message) return { id, ok: false, error, result: { message } };
  return { id, ok: false, error };
}
function str(p, k) {
  const v = p[k];
  return typeof v === "string" ? v : void 0;
}
function num(p, k) {
  const v = p[k];
  return typeof v === "number" && Number.isFinite(v) ? v : void 0;
}
function bool(p, k) {
  const v = p[k];
  return typeof v === "boolean" ? v : void 0;
}
var CmdError = class extends Error {
  constructor(code, message) {
    super(message ?? code);
    this.code = code;
  }
};
async function getTab(tabId) {
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  try {
    return await chrome.tabs.get(tabId);
  } catch {
    throw new CmdError("tab_not_found", `tab ${tabId} not found`);
  }
}
async function cmdNavigate(p) {
  const url = str(p, "url");
  if (!url) throw new CmdError("internal", "url required");
  let tabId = num(p, "tabId");
  let tab;
  if (tabId === void 0) {
    tab = await chrome.tabs.create({ url });
    tabId = tab.id;
  } else {
    tab = await getTab(tabId);
    await chrome.tabs.update(tabId, { url });
  }
  if (tabId === void 0) throw new CmdError("internal", "tab creation returned no id");
  await waitForLoad(tabId, 3e4);
  return { tabId };
}
function waitForLoad(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new CmdError("timeout", `tab ${tabId} load timed out`));
    }, timeoutMs);
    const listener = (updatedId, info) => {
      if (updatedId !== tabId) return;
      if (info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}
async function cmdClick(p) {
  const tabId = num(p, "tabId");
  const selector = str(p, "selector");
  const cdp = bool(p, "cdp") ?? false;
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  if (!selector) throw new CmdError("internal", "selector required");
  await getTab(tabId);
  if (cdp) return clickViaCdp(tabId, selector);
  const out = await chrome.scripting.executeScript({
    target: { tabId },
    args: [selector],
    func: (sel) => {
      const el = document.querySelector(sel);
      if (!el) return { found: false };
      el.click();
      return { found: true };
    }
  });
  const result = out[0]?.result;
  if (!result?.found) throw new CmdError("selector_not_found", selector);
  return {};
}
async function cmdType(p) {
  const tabId = num(p, "tabId");
  const selector = str(p, "selector");
  const text = str(p, "text") ?? "";
  const cdp = bool(p, "cdp") ?? false;
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  if (!selector) throw new CmdError("internal", "selector required");
  await getTab(tabId);
  if (cdp) return typeViaCdp(tabId, selector, text);
  const out = await chrome.scripting.executeScript({
    target: { tabId },
    args: [selector, text],
    func: (sel, value) => {
      const el = document.querySelector(sel);
      if (!el) return { found: false };
      el.focus?.();
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        const setter = Object.getOwnPropertyDescriptor(
          el instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype,
          "value"
        )?.set;
        if (setter) setter.call(el, value);
        else el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el.isContentEditable) {
        el.textContent = value;
        el.dispatchEvent(new InputEvent("input", { bubbles: true }));
      } else {
        return { found: false };
      }
      return { found: true };
    }
  });
  const result = out[0]?.result;
  if (!result?.found) throw new CmdError("selector_not_found", selector);
  return {};
}
async function cmdSnapshot(p) {
  const tabId = num(p, "tabId");
  const maxBytes = num(p, "max_bytes") ?? SNAPSHOT_DEFAULT_CAP;
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  await getTab(tabId);
  const out = await chrome.scripting.executeScript({
    target: { tabId },
    args: [maxBytes],
    func: (cap) => {
      const html2 = document.documentElement.outerHTML;
      return html2.length > cap ? html2.slice(0, cap) : html2;
    }
  });
  const html = out[0]?.result ?? "";
  return { html };
}
async function cmdScreenshot(p) {
  const tabId = num(p, "tabId");
  const format = str(p, "format") ?? "png";
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  const tab = await getTab(tabId);
  if (tab.windowId === void 0) throw new CmdError("internal", "tab missing windowId");
  const data_url = await chrome.tabs.captureVisibleTab(tab.windowId, { format });
  return { data_url };
}
async function cmdEval(p) {
  const tabId = num(p, "tabId");
  const name = str(p, "name");
  const args = p.args && typeof p.args === "object" ? p.args : {};
  if (tabId === void 0) throw new CmdError("tab_not_found", "tabId required");
  if (!name) throw new CmdError("eval_not_allowlisted", "name required");
  const fn = EVAL_ALLOWLIST[name];
  if (!fn) throw new CmdError("eval_not_allowlisted", name);
  return fn(args, tabId);
}
async function clickViaCdp(tabId, selector) {
  await chrome.debugger.attach({ tabId }, "1.3");
  try {
    const rect = await resolveRect(tabId, selector);
    const x = rect.x + rect.width / 2;
    const y = rect.y + rect.height / 2;
    await sendCdp(tabId, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x,
      y,
      button: "left",
      clickCount: 1
    });
    await sendCdp(tabId, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x,
      y,
      button: "left",
      clickCount: 1
    });
    return {};
  } finally {
    await safeDetach(tabId);
  }
}
async function typeViaCdp(tabId, selector, text) {
  await chrome.debugger.attach({ tabId }, "1.3");
  try {
    await sendCdp(tabId, "Runtime.evaluate", {
      expression: `(function(){var el=document.querySelector(${JSON.stringify(selector)});if(el&&el.focus)el.focus();return !!el;})()`,
      returnByValue: true
    });
    for (const ch of text) {
      await sendCdp(tabId, "Input.dispatchKeyEvent", { type: "keyDown", text: ch });
      await sendCdp(tabId, "Input.dispatchKeyEvent", { type: "keyUp", text: ch });
    }
    return {};
  } finally {
    await safeDetach(tabId);
  }
}
async function resolveRect(tabId, selector) {
  const res = await sendCdp(tabId, "Runtime.evaluate", {
    expression: `(function(){var el=document.querySelector(${JSON.stringify(selector)});if(!el)return null;var r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};})()`,
    returnByValue: true
  });
  const rect = res.result?.value;
  if (!rect) throw new CmdError("selector_not_found", selector);
  return rect;
}
function sendCdp(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new CmdError("internal", err.message));
      else resolve(result);
    });
  });
}
async function safeDetach(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
  }
}

// src/background/validate.ts
var UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
var LOWERCASE_EMAIL = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
function isValidRepId(repId) {
  if (repId.length < 3 || repId.length > 254) return false;
  return UUID_V4.test(repId) || LOWERCASE_EMAIL.test(repId);
}
function isAllowedHost(protocol, hostname) {
  if (protocol === "wss:") {
    if (hostname === "cremasales.com") return true;
    if (hostname.endsWith(".cremasales.com")) return true;
    if (hostname.endsWith(".workers.dev")) return true;
    return false;
  }
  if (protocol === "ws:") {
    if (hostname === "localhost" || hostname === "127.0.0.1") return true;
    return false;
  }
  return false;
}
function normalizeBaseUrl(input) {
  if (typeof input !== "string" || !input) return null;
  let s = input.trim();
  s = s.replace(/^http(s?):/i, (_, x) => `ws${x}:`);
  s = s.replace(/\/+$/, "");
  try {
    const u = new URL(s);
    if (u.pathname !== "/" && u.pathname !== "") return null;
    if (u.search || u.hash) return null;
    if (u.username || u.password) return null;
    return `${u.protocol}//${u.host}`;
  } catch {
    return null;
  }
}
function isAllowedBaseUrl(input) {
  const norm = normalizeBaseUrl(input);
  if (norm === null) return false;
  try {
    const u = new URL(norm);
    return isAllowedHost(u.protocol, u.hostname);
  } catch {
    return false;
  }
}

// src/background/dedup.ts
var CAPACITY = 256;
var order = [];
var cache = /* @__PURE__ */ new Map();
function rememberAck(id, resp) {
  if (cache.has(id)) {
    const idx = order.indexOf(id);
    if (idx >= 0) order.splice(idx, 1);
  } else if (order.length >= CAPACITY) {
    const evict = order.shift();
    if (evict !== void 0) cache.delete(evict);
  }
  cache.set(id, resp);
  order.push(id);
}
function recallAck(id) {
  return cache.get(id);
}

// src/background/index.ts
console.log("[crema-agent] service worker boot");
var socket = new AgentSocket(readAgentConfig);
socket.onStatus(async (s) => {
  console.log("[crema-agent] status:", s);
  if (s === "open") {
    const enabled = await getEnabled();
    socket.send({ type: "online", enabled });
  }
});
socket.onMessage(async (msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (!m.id || !m.type || m.type === "pong") return;
  const cached = recallAck(m.id);
  if (cached) {
    console.log(`[crema-agent] dedup hit for ${m.id} \u2014 replaying cached ack`);
    socket.send(cached);
    return;
  }
  const enabled = await getEnabled();
  let resp;
  if (!enabled) {
    resp = { id: m.id, ok: false, error: "rep_disabled" };
  } else {
    resp = await dispatch(m);
  }
  rememberAck(m.id, resp);
  socket.send(resp);
});
void applyVisualState(true);
void (async () => {
  await applyVisualState(await getEnabled());
  attachToggleListener(socket);
  await socket.connect();
})();
var KEEPALIVE_ALARM = "agent-keepalive";
chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === KEEPALIVE_ALARM && !socket.isOpen()) {
    void socket.connect();
  }
});
chrome.runtime.onStartup.addListener(() => {
  console.log("[crema-agent] onStartup");
  void socket.connect();
});
var DEFAULT_ONBOARD_URL = "https://cremasales.com/extension/onboard";
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[crema-agent] onInstalled reason=", details.reason);
  void socket.connect();
  if (details.reason === "install") {
    const { onboardUrl } = await chrome.storage.local.get("onboardUrl");
    const base = typeof onboardUrl === "string" && onboardUrl ? onboardUrl : DEFAULT_ONBOARD_URL;
    const installId = crypto.randomUUID();
    const url = `${base}${base.includes("?") ? "&" : "?"}install_id=${encodeURIComponent(installId)}`;
    try {
      await chrome.tabs.create({ url });
    } catch (err) {
      console.warn("[crema-agent] failed to open onboarding tab:", err);
    }
  }
});
chrome.runtime.onMessageExternal.addListener((message, _sender, sendResponse) => {
  (async () => {
    if (!message || typeof message !== "object") {
      sendResponse({ ok: false, error: "invalid_payload" });
      return;
    }
    const m = message;
    if (m.type !== "agent_handoff") {
      sendResponse({ ok: false, error: "unknown_type" });
      return;
    }
    const repId = typeof m.repId === "string" ? m.repId : "";
    const jwt = typeof m.jwt === "string" ? m.jwt : "";
    const baseUrl = typeof m.baseUrl === "string" ? m.baseUrl : "";
    if (!repId || !jwt || !baseUrl) {
      sendResponse({ ok: false, error: "missing_fields" });
      return;
    }
    if (!isValidRepId(repId)) {
      sendResponse({ ok: false, error: "malformed_repId" });
      return;
    }
    if (!isAllowedBaseUrl(baseUrl)) {
      console.warn("[crema-agent] handoff rejected: baseUrl not allowlisted:", baseUrl);
      sendResponse({ ok: false, error: "baseUrl_not_allowed" });
      return;
    }
    const normalized = normalizeBaseUrl(baseUrl) ?? baseUrl;
    await chrome.storage.local.set({
      agentRepId: repId,
      agentJwt: jwt,
      agentBaseUrl: normalized
    });
    console.log("[crema-agent] agent_handoff persisted for rep", repId);
    void socket.connect();
    sendResponse({ ok: true });
  })();
  return true;
});
globalThis.__cremaAgent = { socket };
//# sourceMappingURL=background.js.map
